<section class="banner-title">
    <div class="container">
        <div class="banner-title__wrapper">
            <div class="banner-title__left">
                <h1 class="page-title">Destilerije</h1>
            </div>
            <div class="banner-title__right">
                <p>U svet vrhunske destilacije! Destilerije su mesto gde se tradicija i savremena tehnologija spajaju kako bi nastala rakija neodoljivog ukusa i vrhunskog kvaliteta. Svaka boca nosi priču - o pažljivo odabranom voću, majstorskoj destilaciji i strasti prema autentičnim aromama.</p>
            </div>
        </div>
    </div>
</section>