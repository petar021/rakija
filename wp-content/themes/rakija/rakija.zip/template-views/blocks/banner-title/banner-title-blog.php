<section class="banner-title gray">
    <div class="container">
        <div class="banner-title__wrapper">
            <div class="banner-title__left">
                <h1 class="page-title">Blog</h1>
                <span>Kod nas ne važi pravilo „sve rakije su iste“</span>
            </div>
            <div class="banner-title__right">
                <p>Ovde delimo priče, savete i tajne o ovom autentičnom piću - od proizvodnje do savršenog gutljaja. Bilo da ste iskusni poznavalac ili tek otkrivate magiju rakije, na pravom ste mestu.</p>
            </div>
        </div>
    </div>
</section>