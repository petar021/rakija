<section class="banner-title gray">
    <div class="container">
        <div class="banner-title__wrapper">
            <div class="banner-title__left">
                <h1 class="page-title">Kontaktirajte nas</h1>
            </div>
            <div class="banner-title__right">
                <p>Za sve upite, pitanja i saradnju, slobodno nas kontaktirajte putem obrasca na našoj stranici ili direktno na našem broju telefona </p>
            </div>
        </div>
    </div>
</section>