<section class="image-block">
    <div class="container">
        <div class="image-block__wrapper" style="background-image: url('https://rakija.baseline.rs/wp-content/uploads/2025/04/destilerija-banner.jpg');">
            <div class="image-block__content">
                <div class="image-block__content-left">
                    <img src="https://rakija.baseline.rs/wp-content/uploads/2025/04/image-07.png" alt="">
                </div>
                <div class="image-block__content-right">    
                    <a href="javascript:;" class="btn-icon btn-icon__reverse" target="_self">
                        <span class="font-arrow-right"></span>
                        Pogledaj ponudu 
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>