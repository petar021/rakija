<section class="three-column-cat">
    <div class="container">
        <div class="three-column-cat__wrapper">
            <a href="javascript:;">
                <div class="three-column-cat__box">
                    <img src="https://rakija.baseline.rs/wp-content/uploads/2025/05/Rakija.png" alt="Rakije">
                    <h2 class="three-column-cat__title">Rakije</h2>
                    <div class="btn-icon">
                        <span class="font-eye"></span>
                        Pogledaj sve
                    </div>
                </div>
            </a>
            <a href="javascript:;">
                <div class="three-column-cat__box">
                    <img src="https://rakija.baseline.rs/wp-content/uploads/2025/05/Liker.png" alt="Likeri">
                    <h2 class="three-column-cat__title">Likeri</h2>
                    <div class="btn-icon">
                        <span class="font-eye"></span>
                        Pogledaj sve
                    </div>
                </div>
            </a>
            <a href="javascript:;">
                <div class="three-column-cat__box">
                    <img src="https://rakija.baseline.rs/wp-content/uploads/2025/05/Dzinovi.png" alt="Dzinovi">
                    <h2 class="three-column-cat__title">Dzinovi</h2>
                    <div class="btn-icon">
                        <span class="font-eye"></span>
                        Pogledaj sve
                    </div>
                </div>
            </a>   
        </div>
    </div>
</section>